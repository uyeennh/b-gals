package fsm

import (
	"fmt"
	"heis/config"
	"heis/driver/elevio"
	"time"
)

func RunFSM(
	io ElevatorIO,
	assignmentCh <-chan [config.N_FLOORS][config.N_BUTTONS]bool,
	finReqCh chan<- elevio.ButtonEvent,
	stateCh chan<- ElevatorStateMsg,
	floorCh <-chan int,
	obstrCh <-chan bool,
) {
	e := elevatorInit()
	doorTimer := NewTimer()
	motorTimer := NewTimer()

	obstrActive := false
	obstrCounter := 0
	obstrStoredFloor := -1

	// serveOppositeOnClose: satt til true etter at primær hall-retning er
	// cleared, og det finnes en sekundær hall-retning som skal serves etter
	// ekstra 3 sekunder (jf. prosjektkravet om retningsskifte).
	serveOppositeOnClose := false

	e.floor = findFloor(io, floorCh)
	io.SetFloorIndicator(e.floor)
	e.dirn = D_Stop
	e.state = ES_Idle
	stateCh <- ElevatorStateMsg{Floor: e.floor, Dirn: e.dirn, State: e.state}

	for {
		select {

		case assignments := <-assignmentCh:
			switch e.state {
			case ES_Idle:
				// Hall requests eies av assigner og settes direkte.
				// Cab requests beholdes lokalt i tillegg til det assigner sender.
				e.requests = preserveCabOnly(e, assignments)

				pair := ChooseDirection(e)
				e.dirn, e.state = pair.dirn, pair.state
				switch e.state {
				case ES_DoorOpen:
					io.SetDoorOpenLamp(true)
					doorTimer.Start(e.elevConfig.DoorOpenDuration)
					setAllLights(io, e)
				case ES_Moving:
					io.SetMotorDirection(e.dirn)
					motorTimer.Start(config.MotorLossTimeout)
				case ES_Idle:
					// Ingen aktive ordre
				}

			case ES_Moving:
				// Mens vi kjører: erstatt hall requests direkte fra assignment.
				// Vi beholder IKKE gamle hall requests "foran oss i retningen".
				// Dette er den viktigste endringen fra gammel mergeRequestsInFlight:
				// hall orders er assigner-owned, og FSM skal aldri holde dem fast
				// lokalt etter at assignment har endret seg. Det var denne
				// lokale retention som førte til at to heiser tok samme hall order.
				e.requests = preserveCabOnly(e, assignments)

			case ES_DoorOpen:
				// Mens døren er åpen: oppdater hall requests fra assigner,
				// behold cab. Ikke restart dørtimerene her.
				e.requests = preserveCabOnly(e, assignments)
				setAllLights(io, e)
			}
			stateCh <- ElevatorStateMsg{Floor: e.floor, Dirn: e.dirn, State: e.state}

		case newFloor := <-floorCh:
			motorTimer.Stop()
			e.floor = newFloor
			io.SetFloorIndicator(newFloor)

			if e.state != ES_Moving {
				stateCh <- ElevatorStateMsg{Floor: e.floor, Dirn: e.dirn, State: e.state}
				continue
			}

			fmt.Printf("[fsm] floor=%d dirn=%v shouldStop=%v HU=%v HD=%v Cab=%v\n",
				e.floor, e.dirn,
				ShouldStop(e),
				e.requests[e.floor][B_HallUp],
				e.requests[e.floor][B_HallDown],
				e.requests[e.floor][B_Cab])

			if ShouldStop(e) {
				io.SetMotorDirection(D_Stop)
				io.SetDoorOpenLamp(true)
				doorTimer.Start(e.elevConfig.DoorOpenDuration)
				setAllLights(io, e)
				e.state = ES_DoorOpen
			} else {
				motorTimer.Start(config.MotorLossTimeout)
			}
			stateCh <- ElevatorStateMsg{Floor: e.floor, Dirn: e.dirn, State: e.state}

		case <-doorTimer.C():
			if e.state != ES_DoorOpen {
				continue
			}

			// Obstruction: hold døren åpen
			if obstrActive {
				doorTimer.Start(e.elevConfig.DoorOpenDuration)
				if obstrCounter == config.ObstrTripsBeforeFloorInvalid {
					obstrStoredFloor = e.floor
					e.floor = -1
					stateCh <- ElevatorStateMsg{Floor: -1, Dirn: e.dirn, State: e.state}
				}
				obstrCounter++
				continue
			}

			// Gjenopprett etasje etter langvarig obstruction
			if e.floor == -1 && obstrStoredFloor != -1 {
				e.floor = obstrStoredFloor
				obstrStoredFloor = -1
			}

			if serveOppositeOnClose {
				// Andre dørperiode: clear sekundær hall-retning
				// (prosjektkrav: etter retningsskifte, hold døren åpen 3 sek til)
				serveOppositeOnClose = false
				clearRequests(&e, finReqCh, true)
				// Fall through til ChooseDirection under
			} else {
				// Første dørperiode: clear cab + primær hall-retning.
				// Returner true hvis sekundær hall-retning skal serves etterpå.
				needsOpposite := clearRequests(&e, finReqCh, false)
				if needsOpposite {
					serveOppositeOnClose = true
					io.SetDoorOpenLamp(true)
					doorTimer.Start(e.elevConfig.DoorOpenDuration)
					stateCh <- ElevatorStateMsg{Floor: e.floor, Dirn: e.dirn, State: e.state}
					continue
				}
			}

			// Velg ny retning etter at alle requests ved denne etasjen er cleared
			pair := ChooseDirection(e)
			e.dirn, e.state = pair.dirn, pair.state

			switch e.state {
			case ES_DoorOpen:
				// Ny request ved samme etasje
				io.SetDoorOpenLamp(true)
				doorTimer.Start(e.elevConfig.DoorOpenDuration)
				setAllLights(io, e)
			case ES_Moving:
				io.SetDoorOpenLamp(false)
				io.SetMotorDirection(e.dirn)
				motorTimer.Start(config.MotorLossTimeout)
			case ES_Idle:
				io.SetDoorOpenLamp(false)
				io.SetMotorDirection(D_Stop)
			}
			stateCh <- ElevatorStateMsg{Floor: e.floor, Dirn: e.dirn, State: e.state}

		case <-motorTimer.C():
			// Motorstopp-feil: sett floor til -1 så distributor ekskluderer oss
			// fra assignment inntil vi er på en kjent etasje igjen
			e.floor = -1
			e.dirn = D_Up
			e.state = ES_Moving
			stateCh <- ElevatorStateMsg{Floor: -1, Dirn: e.dirn, State: e.state}
			io.SetMotorDirection(D_Up)

		case obstr := <-obstrCh:
			obstrActive = obstr
			if obstr {
				if e.state == ES_DoorOpen {
					doorTimer.Start(e.elevConfig.DoorOpenDuration)
				}
			} else {
				obstrCounter = 0
				if e.state == ES_DoorOpen {
					doorTimer.Start(e.elevConfig.DoorOpenDuration)
				}
				stateCh <- ElevatorStateMsg{Floor: e.floor, Dirn: e.dirn, State: e.state}
			}
		}
	}
}

// preserveCabOnly erstatter hall requests direkte med ny assignment,
// men beholder lokale cab-orders som allerede er satt i FSM.
//
// Designprinsipp (som gruppe 70):
//   Hall orders  → eies av assigner, aldri beholdt lokalt i FSM
//   Cab orders   → lokale, beholdes i FSM mellom assignments
//
// Dette hindrer at to heiser kan "holde fast" på samme hall order
// etter at en reassignment har skjedd.
func preserveCabOnly(e Elevator, assignments [config.N_FLOORS][config.N_BUTTONS]bool) [config.N_FLOORS][config.N_BUTTONS]bool {
	merged := assignments
	for f := 0; f < config.N_FLOORS; f++ {
		if e.requests[f][B_Cab] {
			merged[f][B_Cab] = true
		}
	}
	return merged
}

func setAllLights(io ElevatorIO, e Elevator) {
	for f := 0; f < config.N_FLOORS; f++ {
		io.SetButtonLamp(f, B_Cab, e.requests[f][B_Cab])
	}
}

func findFloor(io ElevatorIO, floorCh <-chan int) int {
	if f := elevio.GetFloor(); f != -1 {
		return f
	}

	io.SetMotorDirection(D_Up)
	reversed := false
	t := time.NewTimer(config.MotorLossTimeout)
	defer t.Stop()

	for {
		select {
		case floor := <-floorCh:
			io.SetMotorDirection(D_Stop)
			return floor
		case <-t.C:
			if !reversed {
				io.SetMotorDirection(D_Down)
				reversed = true
			}
		}
	}
}
