package fsm

import (
	"heis/config"
	"heis/driver/elevio"
)

// ChooseDirection bestemmer retning og tilstand basert på aktive requests.
func ChooseDirection(e Elevator) DirnBehaviourPair {
	f := e.floor
	if f < 0 || f >= config.N_FLOORS {
		return DirnBehaviourPair{dirn: D_Stop, state: ES_Idle}
	}

	here := hasRequestsAt(e, f)
	above := requestsAbove(e, f)
	below := requestsBelow(e, f)

	switch e.dirn {
	case D_Up:
		switch {
		case above:
			return DirnBehaviourPair{dirn: D_Up, state: ES_Moving}
		case here:
			return DirnBehaviourPair{dirn: D_Stop, state: ES_DoorOpen}
		case below:
			return DirnBehaviourPair{dirn: D_Down, state: ES_Moving}
		default:
			return DirnBehaviourPair{dirn: D_Stop, state: ES_Idle}
		}

	case D_Down:
		switch {
		case below:
			return DirnBehaviourPair{dirn: D_Down, state: ES_Moving}
		case here:
			return DirnBehaviourPair{dirn: D_Stop, state: ES_DoorOpen}
		case above:
			return DirnBehaviourPair{dirn: D_Up, state: ES_Moving}
		default:
			return DirnBehaviourPair{dirn: D_Stop, state: ES_Idle}
		}

	default: // D_Stop / idle
		switch {
		case here:
			return DirnBehaviourPair{dirn: D_Stop, state: ES_DoorOpen}
		case above:
			return DirnBehaviourPair{dirn: D_Up, state: ES_Moving}
		case below:
			return DirnBehaviourPair{dirn: D_Down, state: ES_Moving}
		default:
			return DirnBehaviourPair{dirn: D_Stop, state: ES_Idle}
		}
	}
}

// ShouldStop avgjør om heisen skal stoppe på nåværende etasje.
func ShouldStop(e Elevator) bool {
	f := e.floor
	if f < 0 || f >= config.N_FLOORS {
		return false
	}

	switch e.dirn {
	case D_Down:
		if e.requests[f][B_Cab] || e.requests[f][B_HallDown] {
			return true
		}
		// Stopp også for HallUp hvis det ikke er noe under oss — vi snur
		return e.requests[f][B_HallUp] && !requestsBelow(e, f)

	case D_Up:
		if e.requests[f][B_Cab] || e.requests[f][B_HallUp] {
			return true
		}
		// Stopp også for HallDown hvis det ikke er noe over oss — vi snur
		return e.requests[f][B_HallDown] && !requestsAbove(e, f)

	case D_Stop:
		return hasRequestsAt(e, f)

	default:
		return false
	}
}

// clearRequests rydder requests for nåværende etasje basert på retning
// og sender finished-events til distributor.
//
// Prosjektkravet (fra oppgaveteksten):
//   Når heisen ankommer en etasje der begge hall-retninger er aktive,
//   skal den IKKE cleare begge samtidig. Den skal:
//     1. Cleare primær retning (den den "annonserte" ved ankomst)
//     2. Hvis ingen videre ordre i primærretningen: hold døren åpen
//        3 sekunder til og cleare sekundær-retningen etterpå
//
// Implementasjon:
//   - Første kall (serveOpposite=false): clear cab + primær hall.
//     Returner true hvis sekundær-retning også trenger å serves.
//   - Andre kall (serveOpposite=true): clear sekundær hall.
//     Kalles av FSM etter den ekstra 3-sekunders dørperioden.
func clearRequests(e *Elevator, finReqCh chan<- elevio.ButtonEvent, serveOpposite bool) bool {
	f := e.floor
	if f < 0 || f >= config.N_FLOORS {
		return false
	}

	if serveOpposite {
		// Andre dørperiode: serve sekundær retning
		switch e.dirn {
		case D_Up:
			// Vi kjørte opp, primary var HallUp, sekundær er HallDown
			if e.requests[f][B_HallDown] {
				e.requests[f][B_HallDown] = false
				finReqCh <- elevio.ButtonEvent{Floor: f, Button: elevio.BT_HallDown}
			}
		case D_Down:
			// Vi kjørte ned, primary var HallDown, sekundær er HallUp
			if e.requests[f][B_HallUp] {
				e.requests[f][B_HallUp] = false
				finReqCh <- elevio.ButtonEvent{Floor: f, Button: elevio.BT_HallUp}
			}
		}
		return false
	}

	// Første dørperiode: clear cab alltid
	if e.requests[f][B_Cab] {
		e.requests[f][B_Cab] = false
		finReqCh <- elevio.ButtonEvent{Floor: f, Button: elevio.BT_Cab}
	}

	switch e.dirn {
	case D_Up:
		// Clear HallUp (primær retning)
		if e.requests[f][B_HallUp] {
			e.requests[f][B_HallUp] = false
			finReqCh <- elevio.ButtonEvent{Floor: f, Button: elevio.BT_HallUp}
		}
		// Har vi HallDown og ingen videre ordre oppover?
		// → trenger ekstra dørperiode for å serve sekundær
		if e.requests[f][B_HallDown] && !requestsAbove(*e, f) {
			return true // signal: hold døren åpen én runde til
		}

	case D_Down:
		// Clear HallDown (primær retning)
		if e.requests[f][B_HallDown] {
			e.requests[f][B_HallDown] = false
			finReqCh <- elevio.ButtonEvent{Floor: f, Button: elevio.BT_HallDown}
		}
		// Har vi HallUp og ingen videre ordre nedover?
		// → trenger ekstra dørperiode for å serve sekundær
		if e.requests[f][B_HallUp] && !requestsBelow(*e, f) {
			return true
		}

	default: // D_Stop — ingen "annonsert retning", clear begge
		if e.requests[f][B_HallUp] {
			e.requests[f][B_HallUp] = false
			finReqCh <- elevio.ButtonEvent{Floor: f, Button: elevio.BT_HallUp}
		}
		if e.requests[f][B_HallDown] {
			e.requests[f][B_HallDown] = false
			finReqCh <- elevio.ButtonEvent{Floor: f, Button: elevio.BT_HallDown}
		}
	}

	return false
}

// --- hjelpefunksjoner ---

func hasRequestsAt(e Elevator, floor int) bool {
	for b := 0; b < config.N_BUTTONS; b++ {
		if e.requests[floor][b] {
			return true
		}
	}
	return false
}

func requestsAbove(e Elevator, floor int) bool {
	for f := floor + 1; f < config.N_FLOORS; f++ {
		if hasRequestsAt(e, f) {
			return true
		}
	}
	return false
}

func requestsBelow(e Elevator, floor int) bool {
	for f := 0; f < floor; f++ {
		if hasRequestsAt(e, f) {
			return true
		}
	}
	return false
}
